package controller; // Ensure the correct package is used

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.*;
import view.RaceTrackPanel;
import view.RaceView;
import view.ScorePanel;
import view.TimerPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class RaceController implements Initializable {
    private Stage primaryStage;
    private String difficulty;
    private String user1Wheel, user1Engine;
    private String user2Wheel, user2Engine;
    private RaceView raceView; // UI component
    private Track track;
    private List<Car> cars;

        @FXML
    private TimerPanel timerPanel;      // Timer UI
    @FXML
    private ScorePanel scorePanel;      // Score UI
    @FXML
    private RaceTrackPanel trackPanel;  // Race track UI
    @FXML
    private AnchorPane controlPanel;          // Control panel
    @FXML
    private Button startButton, pauseButton, restartButton;
    @FXML
    private ImageView player_car; 

    public void initialize(Stage primaryStage, String difficulty, String user1Wheel, String user1Engine, String user2Wheel, String user2Engine) {
        this.primaryStage = primaryStage;
        this.difficulty = difficulty;
        this.user1Wheel = user1Wheel;
        this.user1Engine = user1Engine;
        this.user2Wheel = user2Wheel;
        this.user2Engine = user2Engine;
        //startRace();
    }
    @Override
        public void initialize(URL location, ResourceBundle resources) {
        // Bind button actions
        //startButton.setOnAction(e -> timerPanel.startTimer());
        //pauseButton.setOnAction(e -> timerPanel.stopTimer());
        //restartButton.setOnAction(e -> timerPanel.resetTimer());
        
    }

    private void setTrackAndCars(Track track2, List<Car> cars2) {
        this.track = track;
        this.cars = cars;
    }

   /*  public void startRace() {
        // Initialize the race track
        //Track track = new Track(difficulty);

        // **Create two race cars using CarFactory**
        this.cars = new ArrayList<>();
        //cars.add(CarFactory.createCar(1, track.getStops().get(0), user1Wheel, user1Engine)); // Player 1's car
        //cars.add(CarFactory.createCar(2, track.getStops().get(1), user2Wheel, user2Engine)); // Player 2's car

         try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/RaceView.fxml"));
            Parent root = loader.load();

            // Get the controller and pass data to it
            RaceController raceController = loader.getController();
            raceController.setTrackAndCars(track, cars);
            
                        Scene raceScene = new Scene(root);
                        primaryStage.setScene(raceScene);
                        primaryStage.setTitle("Racing Game");
                        primaryStage.show();
            
                        // Set up keyboard input listeners to control the race cars
                        setupKeyHandlers(raceScene);
            
                        // Start game logic
                        startGameLoop();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            */

                // Listen for keyboard events to control both race cars
    private void setupKeyHandlers(Scene scene) {
        scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {

            raceView.updateRaceTrack(); // Update RaceTrackPanel to redraw the scene
        });
    }

    private void startGameLoop() {
        // Here, you can add a game loop using AnimationTimer to control car movement
    }
}

